$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogDir = Join-Path $Root 'logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$GuiLog = Join-Path $LogDir 'gui-launcher.log'
$LastErrorFile = Join-Path $LogDir 'LAST_ERROR.txt'

function Write-GuiLog([string]$Message) {
    $line = ('{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'), $Message)
    Add-Content -LiteralPath $GuiLog -Value $line -Encoding UTF8
}

function Record-GuiError([System.Management.Automation.ErrorRecord]$Err, [string]$Context) {
    $text = @"
NEXUS VM Lab GUI failure
Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Context: $Context
Message: $($Err.Exception.Message)
Category: $($Err.CategoryInfo)
Position: $($Err.InvocationInfo.PositionMessage)
Script stack:
$($Err.ScriptStackTrace)

Full error:
$($Err | Format-List * -Force | Out-String)
"@
    Set-Content -LiteralPath $LastErrorFile -Value $text -Encoding UTF8
    Write-GuiLog ("ERROR [{0}] {1}" -f $Context,$Err.Exception.Message)
    return $text
}

function Find-QemuGui {
    $cmd = Get-Command 'qemu-system-x86_64.exe' -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $paths = @(
        "$env:ProgramFiles\qemu\qemu-system-x86_64.exe",
        $(if (${env:ProgramFiles(x86)}) { "${env:ProgramFiles(x86)}\qemu\qemu-system-x86_64.exe" }),
        "$env:LOCALAPPDATA\Programs\qemu\qemu-system-x86_64.exe",
        "$env:LOCALAPPDATA\qemu\qemu-system-x86_64.exe"
    ) | Where-Object { $_ }
    foreach ($p in $paths) { if (Test-Path -LiteralPath $p -PathType Leaf) { return $p } }
    $regRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($rr in $regRoots) {
        $apps = Get-ItemProperty $rr -ErrorAction SilentlyContinue | Where-Object {
            $_.DisplayName -match 'QEMU' -and $_.InstallLocation
        }
        foreach ($app in $apps) {
            $p = Join-Path $app.InstallLocation 'qemu-system-x86_64.exe'
            if (Test-Path -LiteralPath $p -PathType Leaf) { return $p }
        }
    }
    return $null
}

try {
    Write-GuiLog 'GUI launcher starting.'
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $startScript = Join-Path $Root 'Start-NEXUS-VM.ps1'
    $captureScript = Join-Path $Root 'Capture-NEXUS-USB.ps1'
    $setupScript = Join-Path $Root 'Setup-NEXUS-VM.ps1'
    $diagScript = Join-Path $Root 'Preflight-NEXUS-VM.ps1'

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'NEXUS OS VM Lab v9 (Legacy UI)'
    $form.Size = New-Object System.Drawing.Size(760,500)
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false

    $title = New-Object System.Windows.Forms.Label
    $title.Text = 'NEXUS OS Virtual Test Lab v7 · Legacy UI'
    $title.Font = New-Object System.Drawing.Font('Segoe UI',16,[System.Drawing.FontStyle]::Bold)
    $title.Location = New-Object System.Drawing.Point(24,18)
    $title.AutoSize = $true
    $form.Controls.Add($title)

    $desc = New-Object System.Windows.Forms.Label
    $desc.Text = 'Boot a NEXUS ISO or USB image in QEMU/UEFI. v4 suppresses nested SVM/VMX and treats QEMU stderr as diagnostics, not automatic failure.'
    $desc.Location = New-Object System.Drawing.Point(27,55)
    $desc.Size = New-Object System.Drawing.Size(690,40)
    $form.Controls.Add($desc)

    $qemuStatus = New-Object System.Windows.Forms.Label
    $qemuStatus.Location = New-Object System.Drawing.Point(27,88)
    $qemuStatus.Size = New-Object System.Drawing.Size(685,18)
    $qemuFoundAtStartup = Find-QemuGui
    if ($qemuFoundAtStartup) {
        $qemuStatus.Text = 'QEMU status: READY - ' + $qemuFoundAtStartup
        $qemuStatus.ForeColor = [System.Drawing.Color]::DarkGreen
    } else {
        $qemuStatus.Text = 'QEMU status: NOT INSTALLED - Start VM will offer automatic installation.'
        $qemuStatus.ForeColor = [System.Drawing.Color]::DarkRed
    }
    $form.Controls.Add($qemuStatus)

    $lblBoot = New-Object System.Windows.Forms.Label
    $lblBoot.Text = 'NEXUS ISO / USB image:'
    $lblBoot.Location = New-Object System.Drawing.Point(27,112)
    $lblBoot.AutoSize = $true
    $form.Controls.Add($lblBoot)

    $txtBoot = New-Object System.Windows.Forms.TextBox
    $txtBoot.Location = New-Object System.Drawing.Point(27,135)
    $txtBoot.Size = New-Object System.Drawing.Size(575,25)
    $form.Controls.Add($txtBoot)

    $browse = New-Object System.Windows.Forms.Button
    $browse.Text = 'Browse...'
    $browse.Location = New-Object System.Drawing.Point(612,133)
    $browse.Size = New-Object System.Drawing.Size(100,28)
    $browse.Add_Click({
        try {
            $dlg = New-Object System.Windows.Forms.OpenFileDialog
            $dlg.Filter = 'NEXUS boot images (*.iso;*.img;*.raw;*.bin)|*.iso;*.img;*.raw;*.bin|All files (*.*)|*.*'
            if ($dlg.ShowDialog() -eq 'OK') {
                $txtBoot.Text = $dlg.FileName
                Write-GuiLog ("Selected boot image: {0}" -f $dlg.FileName)
            }
        } catch {
            $detail = Record-GuiError $_ 'Browse image'
            [System.Windows.Forms.MessageBox]::Show($detail,'NEXUS VM Lab error','OK','Error') | Out-Null
        }
    })
    $form.Controls.Add($browse)

    $lblProfile = New-Object System.Windows.Forms.Label
    $lblProfile.Text = 'Hardware profile:'
    $lblProfile.Location = New-Object System.Drawing.Point(27,180)
    $lblProfile.AutoSize = $true
    $form.Controls.Add($lblProfile)

    $comboProfile = New-Object System.Windows.Forms.ComboBox
    $comboProfile.DropDownStyle = 'DropDownList'
    [void]$comboProfile.Items.AddRange(@('Compat','Legacy','Modern'))
    $comboProfile.SelectedIndex = 0
    $comboProfile.Location = New-Object System.Drawing.Point(27,202)
    $comboProfile.Size = New-Object System.Drawing.Size(160,25)
    $form.Controls.Add($comboProfile)

    $lblRam = New-Object System.Windows.Forms.Label
    $lblRam.Text = 'RAM (MB):'
    $lblRam.Location = New-Object System.Drawing.Point(220,180)
    $lblRam.AutoSize = $true
    $form.Controls.Add($lblRam)

    $numRam = New-Object System.Windows.Forms.NumericUpDown
    $numRam.Minimum = 512
    $numRam.Maximum = 65536
    $numRam.Increment = 512
    $numRam.Value = 4096
    $numRam.Location = New-Object System.Drawing.Point(220,202)
    $numRam.Size = New-Object System.Drawing.Size(115,25)
    $form.Controls.Add($numRam)

    $lblCpu = New-Object System.Windows.Forms.Label
    $lblCpu.Text = 'vCPUs:'
    $lblCpu.Location = New-Object System.Drawing.Point(365,180)
    $lblCpu.AutoSize = $true
    $form.Controls.Add($lblCpu)

    $numCpu = New-Object System.Windows.Forms.NumericUpDown
    $numCpu.Minimum = 1
    $numCpu.Maximum = 32
    $numCpu.Value = 4
    $numCpu.Location = New-Object System.Drawing.Point(365,202)
    $numCpu.Size = New-Object System.Drawing.Size(90,25)
    $form.Controls.Add($numCpu)

    $reset = New-Object System.Windows.Forms.CheckBox
    $reset.Text = 'Start with clean COW overlay'
    $reset.Location = New-Object System.Drawing.Point(490,196)
    $reset.AutoSize = $true
    $form.Controls.Add($reset)

    $forceTcg = New-Object System.Windows.Forms.CheckBox
    $forceTcg.Text = 'Force TCG (disable WHPX)'
    $forceTcg.Location = New-Object System.Drawing.Point(490,220)
    $forceTcg.AutoSize = $true
    $form.Controls.Add($forceTcg)

    $start = New-Object System.Windows.Forms.Button
    $start.Text = 'Start NEXUS VM'
    $start.Location = New-Object System.Drawing.Point(27,260)
    $start.Size = New-Object System.Drawing.Size(205,50)
    $start.Font = New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
    $start.Add_Click({
        try {
            if (-not (Test-Path -LiteralPath $txtBoot.Text -PathType Leaf)) {
                [System.Windows.Forms.MessageBox]::Show('Select a valid NEXUS ISO or IMG first.','NEXUS VM Lab','OK','Warning') | Out-Null
                return
            }

            $qemuNow = Find-QemuGui
            if (-not $qemuNow) {
                $answer = [System.Windows.Forms.MessageBox]::Show(
                    'QEMU is required but is not installed. Install QEMU automatically with WinGet now? A Windows UAC prompt may appear.',
                    'NEXUS VM Lab - QEMU required',
                    [System.Windows.Forms.MessageBoxButtons]::YesNo,
                    [System.Windows.Forms.MessageBoxIcon]::Question)
                if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }

                Write-GuiLog 'QEMU missing at Start; launching automatic elevated setup.'
                $proc = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @(
                    '-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $setupScript)
                ) -WorkingDirectory $Root -Wait -PassThru

                $qemuNow = Find-QemuGui
                if (-not $qemuNow) {
                    [System.Windows.Forms.MessageBox]::Show(
                        'QEMU installation did not become available. Open logs\LAST_ERROR.txt or use Setup / Check QEMU.',
                        'NEXUS VM Lab', 'OK', 'Error') | Out-Null
                    return
                }
                $qemuStatus.Text = 'QEMU status: READY - ' + $qemuNow
                $qemuStatus.ForeColor = [System.Drawing.Color]::DarkGreen
                Write-GuiLog ('Automatic QEMU setup succeeded: {0}' -f $qemuNow)
            }

            $argList = @(
                '-NoExit',
                '-NoProfile',
                '-ExecutionPolicy','Bypass',
                '-File',('"{0}"' -f $startScript),
                '-BootPath',('"{0}"' -f $txtBoot.Text),
                '-Profile',[string]$comboProfile.SelectedItem,
                '-MemoryMB',[string][int]$numRam.Value,
                '-CPUs',[string][int]$numCpu.Value,
                '-PauseOnError'
            )
            if ($reset.Checked) { $argList += '-ResetOverlay' }
            if ($forceTcg.Checked) { $argList += '-NoWHPX' }

            Write-GuiLog ("Starting VM. Profile={0}; RAM={1}; CPUs={2}; ForceTCG={3}; Image={4}" -f $comboProfile.SelectedItem,[int]$numRam.Value,[int]$numCpu.Value,$forceTcg.Checked,$txtBoot.Text)
            Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -WorkingDirectory $Root -WindowStyle Normal | Out-Null
        } catch {
            $detail = Record-GuiError $_ 'Start NEXUS VM'
            [System.Windows.Forms.MessageBox]::Show($detail,'NEXUS VM startup error','OK','Error') | Out-Null
        }
    })
    $form.Controls.Add($start)

    $capture = New-Object System.Windows.Forms.Button
    $capture.Text = 'Capture NEXUS USB'
    $capture.Location = New-Object System.Drawing.Point(250,260)
    $capture.Size = New-Object System.Drawing.Size(205,50)
    $capture.Add_Click({
        try {
            Write-GuiLog 'Opening USB capture as administrator.'
            Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @('-NoExit','-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $captureScript)) -WorkingDirectory $Root | Out-Null
        } catch {
            $detail = Record-GuiError $_ 'Capture NEXUS USB'
            [System.Windows.Forms.MessageBox]::Show($detail,'NEXUS VM Lab error','OK','Error') | Out-Null
        }
    })
    $form.Controls.Add($capture)

    $setup = New-Object System.Windows.Forms.Button
    $setup.Text = 'Setup / Check QEMU'
    $setup.Location = New-Object System.Drawing.Point(473,260)
    $setup.Size = New-Object System.Drawing.Size(205,50)
    $setup.Add_Click({
        try {
            Write-GuiLog 'Opening QEMU setup/check as administrator.'
            Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList @('-NoExit','-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $setupScript)) -WorkingDirectory $Root | Out-Null
        } catch {
            $detail = Record-GuiError $_ 'Setup / Check QEMU'
            [System.Windows.Forms.MessageBox]::Show($detail,'NEXUS VM Lab error','OK','Error') | Out-Null
        }
    })
    $form.Controls.Add($setup)

    $diag = New-Object System.Windows.Forms.Button
    $diag.Text = 'Run VM Diagnostics'
    $diag.Location = New-Object System.Drawing.Point(27,327)
    $diag.Size = New-Object System.Drawing.Size(205,42)
    $diag.Add_Click({
        try {
            $diagArgs = @('-NoExit','-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $diagScript))
            if (Test-Path -LiteralPath $txtBoot.Text -PathType Leaf) {
                $diagArgs += @('-BootPath',('"{0}"' -f $txtBoot.Text),'-Profile',[string]$comboProfile.SelectedItem)
            }
            Write-GuiLog 'Opening diagnostics console.'
            Start-Process -FilePath 'powershell.exe' -ArgumentList $diagArgs -WorkingDirectory $Root -WindowStyle Normal | Out-Null
        } catch {
            $detail = Record-GuiError $_ 'Run diagnostics'
            [System.Windows.Forms.MessageBox]::Show($detail,'NEXUS VM diagnostics error','OK','Error') | Out-Null
        }
    })
    $form.Controls.Add($diag)

    $openLogs = New-Object System.Windows.Forms.Button
    $openLogs.Text = 'Open Logs Folder'
    $openLogs.Location = New-Object System.Drawing.Point(250,327)
    $openLogs.Size = New-Object System.Drawing.Size(205,42)
    $openLogs.Add_Click({
        try { Start-Process explorer.exe -ArgumentList ('"{0}"' -f $LogDir) | Out-Null }
        catch {
            $detail = Record-GuiError $_ 'Open logs folder'
            [System.Windows.Forms.MessageBox]::Show($detail,'NEXUS VM Lab error','OK','Error') | Out-Null
        }
    })
    $form.Controls.Add($openLogs)

    $foot = New-Object System.Windows.Forms.Label
    $foot.Text = 'All profiles use NEXUS-compatible e1000 networking. UEFI state is image-scoped; failures remain on screen and in logs\\LAST_ERROR.txt.'
    $foot.Location = New-Object System.Drawing.Point(27,410)
    $foot.Size = New-Object System.Drawing.Size(685,34)
    $form.Controls.Add($foot)

    [void]$form.ShowDialog()
    Write-GuiLog 'GUI launcher closed normally.'
    exit 0
}
catch {
    $detail = Record-GuiError $_ 'GUI initialization'
    Write-Host $detail -ForegroundColor Red
    exit 1
}
