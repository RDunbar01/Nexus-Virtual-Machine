@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "%~dp0state\bridge-token.txt" (
  echo No bridge token exists yet. Run NEXUS-VM-Lab.cmd first.
  pause
  exit /b 1
)
set /p NEXUS_TOKEN=<"%~dp0state\bridge-token.txt"
powershell.exe -NoProfile -STA -NoExit -ExecutionPolicy Bypass -File "%~dp0NEXUS-VM-Bridge.ps1" -Port 8765 -SessionToken "%NEXUS_TOKEN%"
