@echo off
setlocal
cd /d "%~dp0"
echo NEXUS VM diagnostics will remain open when complete.
echo.
powershell.exe -NoExit -NoProfile -ExecutionPolicy Bypass -File "%~dp0Preflight-NEXUS-VM.ps1"
endlocal
