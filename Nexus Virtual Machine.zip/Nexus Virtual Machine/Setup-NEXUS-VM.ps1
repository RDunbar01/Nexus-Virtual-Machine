[CmdletBinding()]
param([switch]$EnableWHPX)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogDir = Join-Path $Root 'logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log = Join-Path $LogDir ("setup-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
Start-Transcript -Path $Log -Force | Out-Null
try {
    function Test-Qemu {
        $cmd = Get-Command 'qemu-system-x86_64.exe' -ErrorAction SilentlyContinue
        if ($cmd) { return $cmd.Source }

        $paths = @(
            "$env:ProgramFiles\qemu\qemu-system-x86_64.exe",
            $(if (${env:ProgramFiles(x86)}) { "${env:ProgramFiles(x86)}\qemu\qemu-system-x86_64.exe" }),
            "$env:LOCALAPPDATA\Programs\qemu\qemu-system-x86_64.exe",
            "$env:LOCALAPPDATA\qemu\qemu-system-x86_64.exe"
        ) | Where-Object { $_ }
        foreach ($p in $paths) { if (Test-Path -LiteralPath $p -PathType Leaf) { return $p } }

        # Winget/NSIS installs normally populate an uninstall registry entry.  Use
        # InstallLocation so non-default install directories are discovered too.
        $regRoots = @(
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
            'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
        )
        foreach ($rr in $regRoots) {
            $apps = Get-ItemProperty $rr -ErrorAction SilentlyContinue | Where-Object {
                $_.DisplayName -match 'QEMU' -and $_.InstallLocation
            }
            foreach ($app in $apps) {
                $p = Join-Path $app.InstallLocation 'qemu-system-x86_64.exe'
                if (Test-Path -LiteralPath $p -PathType Leaf) { return $p }
            }
        }
        return $null
    }

    $qemu = Test-Qemu
    if (-not $qemu) {
        Write-Host 'QEMU was not found.' -ForegroundColor Yellow
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if (-not $winget) {
            throw 'WinGet is not available. Install the current 64-bit Windows QEMU build, then rerun this check.'
        }
        Write-Host 'Searching WinGet for QEMU packages...' -ForegroundColor Cyan
        & winget search QEMU
        Write-Host ''
        Write-Host 'Installing QEMU with WinGet (SoftwareFreedomConservancy.QEMU)...' -ForegroundColor Cyan
        & winget install --id SoftwareFreedomConservancy.QEMU --exact --accept-package-agreements --accept-source-agreements
        if ($LASTEXITCODE -ne 0) {
            throw 'WinGet could not install SoftwareFreedomConservancy.QEMU. Use the search results above to install QEMU manually, then rerun diagnostics.'
        }
        $qemu = Test-Qemu
        if (-not $qemu) { throw 'QEMU installation completed but qemu-system-x86_64.exe is still not discoverable.' }
    }
    Write-Host "QEMU found: $qemu" -ForegroundColor Green
    & $qemu --version

    $feature = Get-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform -ErrorAction SilentlyContinue
    if ($feature -and $feature.State -eq 'Enabled') {
        Write-Host 'Windows Hypervisor Platform (WHPX) is enabled.' -ForegroundColor Green
    }
    elseif ($EnableWHPX) {
        Write-Host 'Enabling Windows Hypervisor Platform...' -ForegroundColor Cyan
        Enable-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform -All -NoRestart | Out-Null
        Write-Host 'WHPX enabled. Windows may require one restart before acceleration becomes available.' -ForegroundColor Yellow
    }
    else {
        Write-Host 'WHPX is not enabled. The VM lab will automatically use TCG until WHPX is enabled.' -ForegroundColor Yellow
        Write-Host 'To enable it: rerun this script with -EnableWHPX.' -ForegroundColor Yellow
    }

    Write-Host ''
    Write-Host "Setup log: $Log" -ForegroundColor Cyan
    Write-Host 'Setup/check complete. Run VM Diagnostics next.' -ForegroundColor Green
}
catch {
    $text = $_ | Format-List * -Force | Out-String
    Set-Content -LiteralPath (Join-Path $LogDir 'LAST_ERROR.txt') -Value $text -Encoding UTF8
    Write-Host $text -ForegroundColor Red
    throw
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
}
