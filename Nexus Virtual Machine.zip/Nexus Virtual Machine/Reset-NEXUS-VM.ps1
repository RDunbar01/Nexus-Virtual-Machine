[CmdletBinding(SupportsShouldProcess=$true, ConfirmImpact='Medium')]
param([switch]$AllState)
$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$State=Join-Path $Root 'state'
if(-not (Test-Path -LiteralPath $State)){ Write-Host 'No VM state directory exists.'; exit 0 }
$targets=Get-ChildItem -LiteralPath $State -File | Where-Object {
    if($AllState){$true}else{$_.Name -like '*-work.qcow2'}
}
if(-not $targets){Write-Host 'No matching VM overlays found.'; exit 0}
foreach($t in $targets){
    if($PSCmdlet.ShouldProcess($t.FullName,'Delete VM state file')){Remove-Item -LiteralPath $t.FullName -Force; Write-Host "Deleted $($t.Name)" -ForegroundColor Green}
}
