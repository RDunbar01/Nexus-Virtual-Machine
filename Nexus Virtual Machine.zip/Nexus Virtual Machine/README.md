# NEXUS VM Studio v9 — W1.1R3 VMBOOT1 / Network / AEGIS

NEXUS VM Studio v9 is the HTML control surface for the proven NEXUS QEMU VM engine. It keeps the Imaging Studio / AEGIS visual language while moving VM controls into the browser.

## Important: launch the application with the CMD file

Run:

`NEXUS-VM-Lab.cmd`

Do **not** open `NEXUS-VM-Lab.html` directly. A normal HTML file cannot start QEMU, open a native Windows path selector, inspect USB disks, or access the host logs by itself.

v6 fixes the v5 bridge-start race/failure mode by adding a dedicated launcher:

1. creates/reuses the local session token;
2. finds a free loopback port (8765–8774);
3. starts the PowerShell native bridge;
4. polls `/api/ping` until the bridge answers successfully;
5. opens the HTML interface only after the health check passes;
6. captures bridge stdout/stderr if startup fails.

If the bridge cannot start, the launcher **does not open a broken HTML page**. It leaves a readable console error and writes `logs\LAST_ERROR.txt`.

## Image selection fix

v5 opened `System.Windows.Forms.OpenFileDialog` inside the HTTP bridge process. v6 moves the file chooser into a dedicated STA helper:

`Select-NEXUS-Image.ps1`

This isolates the Windows dialog from the HTTP listener and gives it a top-most native owner window. The SELECT IMAGE button calls the bridge, the bridge starts the helper, and the helper returns the selected full Windows path through a temporary JSON state file.

The boot-path text box remains editable as a fallback. You may paste a full `.img`, `.iso`, `.raw`, or `.bin` path and press Tab/Enter to trigger validation.

## Bridge diagnostics

Key files:

- `logs\bridge-launcher.log` — launcher and health-check sequence
- `logs\bridge-stdout.log` — native bridge stdout
- `logs\bridge-stderr.log` — native bridge stderr
- `logs\web-bridge.log` — HTTP/API activity
- `logs\LAST_ERROR.txt` — most recent fatal bridge/start failure

`DEBUG-BRIDGE.cmd` starts the bridge in a visible PowerShell window if a deeper diagnostic is needed.

## VM engine

The underlying v4 VM engine is retained:

- i440fx/pc machine (deterministic legacy PCI config for NEXUS network qualification)
- UEFI / EDK2
- 4096 MB RAM default
- 4 vCPUs default
- `qemu64,hypervisor=on,svm=off,vmx=off`
- WHPX with TCG fallback when Force TCG is disabled
- forced TCG option
- e1000 compatibility NIC
- W1.1R3 note: VM networking is QEMU user-mode NAT over the host connection. Every profile presents Intel 82540EM Ethernet (8086:100E), not the host Wi-Fi radio or host SSID scan list.
- qcow2 COW overlays for writable guest experiments
- base NEXUS image remains unchanged by normal COW sessions

## Recommended test sequence

1. Extract the entire ZIP to a normal writable folder.
2. Double-click `NEXUS-VM-Lab.cmd`.
3. Wait for the browser to open automatically.
4. Confirm the Settings / Runtime bridge card says **ONLINE**.
5. Click **SELECT IMAGE** and choose the NEXUS IMG/ISO.
6. Use `Compat`, 4096 MB, 4 CPUs.
7. Start with Force TCG either enabled or disabled; both were reported working in the prior v4 test.
8. Click **START NEXUS VM**.

If the browser displays `NATIVE BRIDGE OFFLINE` immediately, close that tab and run `NEXUS-VM-Lab.cmd`. If the CMD launcher itself reports a failure, use `logs\LAST_ERROR.txt` rather than debugging the HTML layer.

## W1.1R3 VM network rule

All Legacy, Compat, and Modern VM profiles intentionally use the i440fx/pc PCI topology plus QEMU `e1000` (Intel 82540EM, PCI `8086:100E`) when networking is enabled. NEXUS has a native guest driver for that device; it does not yet have guest drivers for QEMU `e1000e`, `rtl8139`, or `virtio-net-pci`. The VM remains behind QEMU user-mode NAT, so Internet traffic exits through the host computer's active connection. NEXUS does **not** see or scan the host Wi-Fi radio/SSIDs unless a physical WLAN adapter is explicitly passed through.

The W1.1R3 NEXUS image also permits a hypervisor-only volatile Normal boot when the M48 persistent Safe-Boot journal cannot be durably updated, after the existing image/security checks have passed. This prevents a QEMU variable-store limitation from silently converting the verified VM boot to M48 Safe Mode and disabling the network DMA provider. The physical-PC boot policy remains fail-closed.

VM Lab v9 also keeps the EDK2/OVMF variable store **per exact boot-image SHA-256**. Selecting a new NEXUS build no longer inherits M48 attempt/security journal state from an older build. Using Reset Overlay also resets that image-scoped firmware-variable file.


## W1.1R3 whole-system network correction

W1.1R3 separates **virtual Ethernet policy** from physical Wi-Fi and storage safety policy. In a VM, the verified QEMU `e1000` device (`8086:100E`) is allowed to be discovered, mapped, have memory decoding/bus mastering enabled after identity/BAR revalidation, and start even when M48 Safe Mode has disabled physical Wi-Fi DMA or physical internal-controller admission. USB ACPI/IOMMU admission is no longer a prerequisite for the emulated Ethernet path.

The guest performs a second bounded PCI segment-0 CF8/CFC discovery after firmware handoff if UEFI did not expose the e1000 handle. BAR0 probing is bounded and restoration-verified; ambiguous adapters fail closed. This is deliberately **not** a blanket bypass for arbitrary hardware drivers. Virtual drivers receive their own device-domain policy, while physical MT7922/storage/GPU/audio paths keep their existing safety gates.

Expected VM status: the physical MT7922 line may say unavailable because QEMU does not emulate the host WLAN radio, but the **VM Internet provider** should report e1000 active and NEXUS Browser should use QEMU NAT through the host connection.

## VMBOOT1 boot and network correction

The screenshot showing **UEFI Interactive Shell v2.2** with `FS0:` mapped to the NEXUS USB proves that OVMF could read the GPT/FAT32 ESP but did not automatically dispatch `EFI\BOOT\BOOTX64.EFI`. The companion `NEXUS_WIFI_W1_1R3_VMBOOT1_256MiB.img` therefore adds `STARTUP.NSH` at the ESP root. If OVMF falls through to the EDK II shell, the normal four-second shell countdown now automatically launches `FS0:\EFI\BOOT\BOOTX64.EFI` instead of leaving the user at the shell prompt.

VM Studio v9 also makes the guest network topology deterministic: all profiles use the i440fx/`pc` PCI machine, set the CPUID hypervisor bit explicitly, expose exactly one Intel 82540EM e1000 NIC at PCI `00:03.0`, and retain QEMU user-mode NAT. Compat/Modern place xHCI at PCI `00:04.0`; Legacy uses the chipset USB controller. This matches the W1.1R3 native driver's CF8/CFC segment-0 discovery and virtual-device safety domain.

The guest does **not** receive the host's Wi-Fi radio. Instead, NEXUS sees a virtual Ethernet adapter. QEMU NAT carries that Ethernet traffic over whichever host connection is active (Wi-Fi or wired Ethernet), and provides guest DHCP/DNS. Physical MT7922 Wi-Fi remains a separate hardware path.
