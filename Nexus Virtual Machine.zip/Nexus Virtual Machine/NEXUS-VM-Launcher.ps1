[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogDir = Join-Path $Root 'logs'
$StateDir = Join-Path $Root 'state'
$BridgeScript = Join-Path $Root 'NEXUS-VM-Bridge.ps1'
$BridgeStateFile = Join-Path $StateDir 'web-bridge.json'
$TokenFile = Join-Path $StateDir 'bridge-token.txt'
$LaunchLog = Join-Path $LogDir 'bridge-launcher.log'
$BridgeStdout = Join-Path $LogDir 'bridge-stdout.log'
$BridgeStderr = Join-Path $LogDir 'bridge-stderr.log'
$LastError = Join-Path $LogDir 'LAST_ERROR.txt'

New-Item -ItemType Directory -Force -Path $LogDir,$StateDir | Out-Null

function Log([string]$Message) {
    $line = ('{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'),$Message)
    Add-Content -LiteralPath $LaunchLog -Value $line -Encoding UTF8
    Write-Host "[NEXUS VM] $Message"
}

function Test-Bridge([int]$Port,[string]$Token) {
    try {
        $headers = @{ 'X-NEXUS-Token' = $Token }
        $r = Invoke-RestMethod -Uri ("http://127.0.0.1:{0}/api/ping" -f $Port) -Headers $headers -Method Get -TimeoutSec 1
        return [bool]$r.ok
    } catch { return $false }
}

function Port-Free([int]$Port) {
    $l = $null
    try {
        $l = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$Port)
        $l.Start()
        return $true
    } catch { return $false }
    finally { if ($l) { try { $l.Stop() } catch {} } }
}

function Fail([string]$Message) {
    $detail = @"
NEXUS VM Studio v9 bridge startup failure
Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Message: $Message

Bridge stderr:
$(if (Test-Path $BridgeStderr) { Get-Content $BridgeStderr -Raw -ErrorAction SilentlyContinue })

Bridge launcher log:
$(if (Test-Path $LaunchLog) { Get-Content $LaunchLog -Tail 80 -ErrorAction SilentlyContinue | Out-String })
"@
    Set-Content -LiteralPath $LastError -Value $detail -Encoding UTF8
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Red
    Write-Host 'NEXUS VM HTML BRIDGE DID NOT START' -ForegroundColor Red
    Write-Host '============================================================' -ForegroundColor Red
    Write-Host $detail
    Write-Host "Diagnostic file: $LastError" -ForegroundColor Yellow
    Read-Host 'Press ENTER after reading the error' | Out-Null
    exit 1
}

try {
    Log 'Starting NEXUS VM Studio v9 launcher.'
    if (-not (Test-Path -LiteralPath $BridgeScript -PathType Leaf)) { Fail "Bridge script is missing: $BridgeScript" }

    if (Test-Path -LiteralPath $TokenFile -PathType Leaf) {
        $token = (Get-Content -LiteralPath $TokenFile -Raw).Trim()
    } else {
        $token = [Guid]::NewGuid().ToString('N')
        Set-Content -LiteralPath $TokenFile -Value $token -Encoding ASCII
    }
    if ([string]::IsNullOrWhiteSpace($token)) {
        $token = [Guid]::NewGuid().ToString('N')
        Set-Content -LiteralPath $TokenFile -Value $token -Encoding ASCII
    }

    # Re-use an already healthy bridge for this lab if it exists.
    if (Test-Path -LiteralPath $BridgeStateFile -PathType Leaf) {
        try {
            $old = Get-Content -LiteralPath $BridgeStateFile -Raw | ConvertFrom-Json
            if ($old.port -and (Test-Bridge ([int]$old.port) $token)) {
                $url = "http://127.0.0.1:$($old.port)/?token=$token"
                Log "Existing bridge is healthy on port $($old.port)."
                Start-Process $url | Out-Null
                exit 0
            }
        } catch { }
        Remove-Item -LiteralPath $BridgeStateFile -Force -ErrorAction SilentlyContinue
    }

    # Prefer 8765 so a refresh/relaunch is predictable; use a short fallback range.
    $port = $null
    foreach ($candidate in 8765..8774) {
        if (Port-Free $candidate) { $port = $candidate; break }
    }
    if (-not $port) { Fail 'No free loopback port was available in the 8765-8774 range.' }

    Remove-Item -LiteralPath $BridgeStdout,$BridgeStderr -Force -ErrorAction SilentlyContinue
    $args = @(
        '-NoProfile','-STA','-ExecutionPolicy','Bypass',
        '-File',('"{0}"' -f $BridgeScript),
        '-Port',[string]$port,
        '-SessionToken',$token
    )
    Log "Launching bridge on 127.0.0.1:$port and waiting for health check."
    $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $args -WorkingDirectory $Root -WindowStyle Hidden -PassThru -RedirectStandardOutput $BridgeStdout -RedirectStandardError $BridgeStderr

    $healthy = $false
    for ($i=0; $i -lt 50; $i++) {
        Start-Sleep -Milliseconds 100
        if ($proc.HasExited) { break }
        if (Test-Bridge $port $token) { $healthy=$true; break }
    }
    if (-not $healthy) {
        $exitText = if ($proc.HasExited) { "Bridge process exited with code $($proc.ExitCode)." } else { 'Bridge process stayed alive but did not answer the health check.' }
        if (-not $proc.HasExited) { try { Stop-Process -Id $proc.Id -Force } catch {} }
        Fail $exitText
    }

    $url = "http://127.0.0.1:$port/?token=$token"
    Log "Bridge health check PASS. Opening HTML interface."
    Start-Process $url | Out-Null
    exit 0
}
catch {
    Fail $_.Exception.Message
}
