[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$BootPath,

    [ValidateSet('Auto','ISO','IMG')]
    [string]$BootType = 'Auto',

    [ValidateSet('Compat','Legacy','Modern')]
    [string]$Profile = 'Compat',

    [ValidateRange(512,65536)]
    [int]$MemoryMB = 4096,

    [ValidateRange(1,32)]
    [int]$CPUs = 4,

    [switch]$ResetOverlay,
    [switch]$NoWHPX,
    [switch]$Ephemeral,
    [switch]$NoNetwork,
    [switch]$PauseOnError
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$StateDir = Join-Path $Root 'state'
$LogDir = Join-Path $Root 'logs'
$ImageDir = Join-Path $Root 'images'
New-Item -ItemType Directory -Force -Path $StateDir,$LogDir,$ImageDir | Out-Null

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$HostLog = Join-Path $LogDir "host-$timestamp.log"
$QemuStdout = Join-Path $LogDir "qemu-stdout-$timestamp.log"
$QemuStderr = Join-Path $LogDir "qemu-stderr-$timestamp.log"
$QemuDebug = Join-Path $LogDir "qemu-debug-$timestamp.log"
$SerialLog = Join-Path $LogDir "serial-$timestamp.log"
$LastErrorFile = Join-Path $LogDir 'LAST_ERROR.txt'
$LatestHost = Join-Path $LogDir 'latest-host.log'
$LatestStderr = Join-Path $LogDir 'latest-qemu-stderr.log'

function Write-Stage([string]$Text) {
    Write-Host ("[NEXUS VM] {0}" -f $Text) -ForegroundColor Cyan
}
function To-QemuPath([string]$Path) {
    return ([IO.Path]::GetFullPath($Path) -replace '\\','/')
}
function Find-QemuTool([string]$Name) {
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $roots = @(
        (Join-Path $env:ProgramFiles 'qemu'),
        $(if (${env:ProgramFiles(x86)}) { Join-Path ${env:ProgramFiles(x86)} 'qemu' }),
        (Join-Path $env:LOCALAPPDATA 'Programs\qemu'),
        (Join-Path $env:LOCALAPPDATA 'qemu')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) }

    foreach ($r in $roots) {
        $candidate = Join-Path $r $Name
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }

    $regRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($rr in $regRoots) {
        $apps = Get-ItemProperty $rr -ErrorAction SilentlyContinue | Where-Object {
            $_.DisplayName -match 'QEMU' -and $_.InstallLocation
        }
        foreach ($app in $apps) {
            $candidate = Join-Path $app.InstallLocation $Name
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
        }
    }
    throw "$Name was not found. QEMU is not installed or its installation is incomplete. Run Setup / Check QEMU."
}
function Find-Firmware([string]$QemuDir,[string[]]$Names) {
    $roots = @(
        $QemuDir,
        (Join-Path $QemuDir 'share'),
        (Join-Path $QemuDir 'pc-bios')
    ) | Where-Object { Test-Path -LiteralPath $_ -PathType Container }

    foreach ($name in $Names) {
        foreach ($root in $roots) {
            $candidate = Join-Path $root $name
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
        }
    }

    foreach ($name in $Names) {
        $hit = Get-ChildItem -LiteralPath $QemuDir -Filter $name -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }
    return $null
}
function Show-FileTail([string]$Path,[int]$Count=40) {
    if (Test-Path -LiteralPath $Path -PathType Leaf) {
        $lines = @(Get-Content -LiteralPath $Path -Tail $Count -ErrorAction SilentlyContinue)
        if ($lines.Count -gt 0) {
            Write-Host "--- $Path (last $Count lines) ---" -ForegroundColor Yellow
            $lines | ForEach-Object { Write-Host $_ -ForegroundColor Red }
        }
    }
}

function Invoke-NativeLogged {
    param(
        [Parameter(Mandatory=$true)][string]$Exe,
        [Parameter(Mandatory=$true)][string[]]$Arguments,
        [Parameter(Mandatory=$true)][string]$Stdout,
        [Parameter(Mandatory=$true)][string]$Stderr
    )
    # Windows PowerShell can promote a native program's stderr text to an
    # ErrorRecord when $ErrorActionPreference='Stop'. QEMU legitimately writes
    # warnings and diagnostics to stderr even when it continues normally.
    # Therefore native stderr is logged, while the native process EXIT CODE is
    # the authoritative success/failure signal.
    $oldPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $Exe @Arguments 1>>$Stdout 2>>$Stderr
        return [int]$LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $oldPreference
    }
}

$transcriptStarted = $false
$exitCode = 1
try {
    Start-Transcript -Path $HostLog -Force | Out-Null
    $transcriptStarted = $true
    Write-Stage 'Host logging started before QEMU discovery.'
    Write-Host "Host log: $HostLog"

    $Qemu = Find-QemuTool 'qemu-system-x86_64.exe'
    $QemuImg = Find-QemuTool 'qemu-img.exe'
    $QemuDir = Split-Path -Parent $Qemu
    Write-Stage "QEMU found at $Qemu"

    $version = (& $Qemu --version 2>&1 | Select-Object -First 1 | Out-String).Trim()
    Write-Host "QEMU version: $version"

    $BootPath = [IO.Path]::GetFullPath($BootPath)
    if (-not (Test-Path -LiteralPath $BootPath -PathType Leaf)) { throw "Boot image not found: $BootPath" }
    $bootItem = Get-Item -LiteralPath $BootPath
    Write-Host ("Boot image size: {0:N2} MB" -f ($bootItem.Length / 1MB))

    if ($BootType -eq 'Auto') {
        $ext = [IO.Path]::GetExtension($BootPath).ToLowerInvariant()
        $BootType = if ($ext -eq '.iso') { 'ISO' } else { 'IMG' }
    }
    Write-Stage "Boot type resolved to $BootType"

    # Validate the selected machine and devices before launching the real VM.
    $machineHelp = (& $Qemu -machine help 2>&1 | Out-String)
    $requiredMachine = 'pc'
    if ($machineHelp -notmatch ('(?m)^' + [regex]::Escape($requiredMachine) + '\s')) {
        throw "This QEMU build does not list the required '$requiredMachine' machine."
    }

    $deviceHelp = (& $Qemu -device help 2>&1 | Out-String)
    $requiredDevices = @('usb-kbd','usb-tablet','usb-storage')
    if ($Profile -ne 'Legacy') { $requiredDevices += @('qemu-xhci') }
    if (-not $NoNetwork) { $requiredDevices += @('e1000') } # NEXUS implements Intel 82540EM 8086:100E
    foreach ($dev in $requiredDevices) {
        if ($deviceHelp -notmatch [regex]::Escape($dev)) { throw "QEMU device '$dev' is not available in this build." }
    }
    Write-Stage 'Machine/device preflight passed.'

    $CodeFw = Find-Firmware $QemuDir @('edk2-x86_64-code.fd','OVMF_CODE.fd','OVMF_CODE_4M.fd')
    $VarsTemplate = Find-Firmware $QemuDir @('edk2-i386-vars.fd','edk2-x86_64-vars.fd','OVMF_VARS.fd','OVMF_VARS_4M.fd')
    if (-not $CodeFw -or -not $VarsTemplate) {
        throw ("UEFI firmware was not found under '{0}'. Code={1}; Vars={2}. Run VM Diagnostics for the full QEMU directory scan." -f $QemuDir,$CodeFw,$VarsTemplate)
    }
    Write-Host "UEFI code: $CodeFw"
    Write-Host "UEFI vars template: $VarsTemplate"

    # W1.1R3: firmware variable state is scoped to the exact NEXUS image.
    # A single cross-build VARS file can carry M48 journal/security state from an
    # older build and make a newly selected image enter Safe Mode unexpectedly.
    $imageHash = (Get-FileHash -LiteralPath $BootPath -Algorithm SHA256).Hash.ToLowerInvariant()
    $imageStateKey = $imageHash.Substring(0,12)
    $VarsFile = Join-Path $StateDir ("NEXUS_UEFI_VARS_{0}.fd" -f $imageStateKey)
    if ($ResetOverlay -and (Test-Path -LiteralPath $VarsFile -PathType Leaf)) {
        Write-Stage 'Resetting image-scoped UEFI variable state.'
        Remove-Item -LiteralPath $VarsFile -Force
    }
    if (-not (Test-Path -LiteralPath $VarsFile -PathType Leaf)) { Copy-Item -LiteralPath $VarsTemplate -Destination $VarsFile }
    Write-Host "UEFI vars: $VarsFile"

    $accelHelp = (& $Qemu -accel help 2>&1 | Out-String)
    $useWhpx = $false
    if (-not $NoWHPX -and $accelHelp -match '(?im)^whpx\s*$|\bwhpx\b') {
        try {
            $feature = Get-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform -ErrorAction Stop
            if ($feature.State -eq 'Enabled') { $useWhpx = $true }
            else { Write-Host 'WHPX is built into QEMU but Windows Hypervisor Platform is not enabled; using TCG.' -ForegroundColor Yellow }
        } catch {
            # A read of Windows optional features can be restricted. In that case,
            # let QEMU attempt WHPX and use its documented accelerator fallback.
            $useWhpx = $true
            Write-Host 'Could not read HypervisorPlatform state; QEMU will attempt WHPX with TCG fallback.' -ForegroundColor Yellow
        }
    }

    $machine = 'pc'
    # NEXUS does not require nested virtualization. The default qemu64 CPU can
    # expose AMD SVM under WHPX, which causes a host-feature warning on systems
    # where WHPX cannot expose SVM. Explicitly disable both nested virtualization
    # extensions for a deterministic cross-vendor guest CPU.
    $cpuModel = 'qemu64,hypervisor=on,svm=off,vmx=off'
    # W1.1R3: virtual networking is a dedicated virtual-device domain. It is not
    # gated by the physical Wi-Fi/storage Safe Mode DMA bits in the guest. All
    # VM profiles present the exact guest-supported Intel 82540EM model.
    # Machine/chipset profiles may vary, but rtl8139/virtio-net are not NEXUS guest drivers yet.
    $nicModel = 'e1000'
    $nicMac = '52:54:00:4e:58:13' # deterministic NEXUS VM locally-administered QEMU MAC
    $usbController = if ($Profile -eq 'Legacy') { @() } else { @('-device','qemu-xhci,id=xhci,bus=pci.0,addr=0x04') }

    $args = @(
        '-name','NEXUS OS VM Lab',
        '-machine',$machine,
        '-cpu',$cpuModel,
        '-smp',[string]$CPUs,
        '-m',[string]$MemoryMB,
        '-rtc','base=localtime',
        '-boot','menu=off',
        '-vga','std',
        '-drive',("if=pflash,format=raw,unit=0,file={0},readonly=on" -f (To-QemuPath $CodeFw)),
        '-drive',("if=pflash,format=raw,unit=1,file={0}" -f (To-QemuPath $VarsFile)),
        '-d','guest_errors,unimp',
        '-D',(To-QemuPath $QemuDebug),
        '-serial',("file:{0}" -f (To-QemuPath $SerialLog)),
        '-monitor','none'
    )

    if ($useWhpx) {
        $args += @('-accel','whpx','-accel','tcg,thread=multi')
        $accelLabel = 'WHPX with TCG fallback'
    } else {
        $args += @('-accel','tcg,thread=multi')
        $accelLabel = 'TCG multi-threaded'
    }

    $args += $usbController
    if ($Profile -eq 'Legacy') {
        $args += @('-device','usb-kbd','-device','usb-tablet')
    } else {
        $args += @('-device','usb-kbd,bus=xhci.0','-device','usb-tablet,bus=xhci.0')
    }

    if (-not $NoNetwork) {
        $args += @('-netdev','user,id=net0','-device',("{0},netdev=net0,id=nexusnet,mac={1},bus=pci.0,addr=0x03" -f $nicModel,$nicMac))
    }

    if ($BootType -eq 'IMG') {
        # Validate that QEMU can inspect the source before trying to overlay it.
        $imgInfoExit = Invoke-NativeLogged -Exe $QemuImg -Arguments @('info','-f','raw',$BootPath) -Stdout $QemuStdout -Stderr $QemuStderr
        if ($imgInfoExit -ne 0) { throw "qemu-img could not read the source image (exit $imgInfoExit). See $QemuStderr" }

        $safeBase = ([IO.Path]::GetFileNameWithoutExtension($BootPath) -replace '[^A-Za-z0-9_.-]','_')
        $Overlay = Join-Path $StateDir ("{0}-work.qcow2" -f $safeBase)
        if ($ResetOverlay -and (Test-Path -LiteralPath $Overlay)) {
            Write-Stage 'Removing previous COW overlay.'
            Remove-Item -LiteralPath $Overlay -Force
        }
        if (-not (Test-Path -LiteralPath $Overlay)) {
            Write-Stage 'Creating copy-on-write USB overlay.'
            $overlayExit = Invoke-NativeLogged -Exe $QemuImg -Arguments @('create','-f','qcow2','-F','raw','-b',(To-QemuPath $BootPath),(To-QemuPath $Overlay)) -Stdout $QemuStdout -Stderr $QemuStderr
            if ($overlayExit -ne 0) { throw "qemu-img could not create the NEXUS overlay (exit $overlayExit). See $QemuStderr" }
        }
        $args += @(
            '-drive',("if=none,id=nexususb,file={0},format=qcow2,cache=writeback" -f (To-QemuPath $Overlay)),
            '-device',$(if ($Profile -eq 'Legacy') {'usb-storage,drive=nexususb,removable=on,bootindex=1'} else {'usb-storage,drive=nexususb,removable=on,bootindex=1,bus=xhci.0'})
        )
    }
    else {
        $LabDisk = Join-Path $StateDir 'NEXUS_LAB_DISK.qcow2'
        if (-not (Test-Path -LiteralPath $LabDisk)) {
            Write-Stage 'Creating 8 GB lab disk.'
            $labDiskExit = Invoke-NativeLogged -Exe $QemuImg -Arguments @('create','-f','qcow2',(To-QemuPath $LabDisk),'8G') -Stdout $QemuStdout -Stderr $QemuStderr
            if ($labDiskExit -ne 0) { throw "qemu-img could not create the lab disk (exit $labDiskExit). See $QemuStderr" }
        }
        $args += @(
            '-drive',("if=none,id=installiso,file={0},format=raw,media=cdrom,readonly=on" -f (To-QemuPath $BootPath)),
            '-device','ide-cd,bus=ide.1,drive=installiso,bootindex=1',
            '-drive',("if=none,id=labdisk,file={0},format=qcow2" -f (To-QemuPath $LabDisk)),
            '-device','ide-hd,bus=ide.0,drive=labdisk,bootindex=2'
        )
    }

    if ($Ephemeral) { $args += '-snapshot' }

    Write-Host ''
    Write-Host 'NEXUS VM configuration' -ForegroundColor Green
    Write-Host "  Boot:        $BootPath"
    Write-Host "  Type:        $BootType"
    Write-Host "  Profile:     $Profile"
    Write-Host "  Machine:     $machine"
    Write-Host "  CPU model:   $cpuModel"
    Write-Host "  Memory:      $MemoryMB MB"
    Write-Host "  CPUs:        $CPUs"
    Write-Host "  Accelerator: $accelLabel"
    Write-Host "  NIC:         $(if ($NoNetwork) {'disabled'} else {("{0} / 8086:100E / {1}" -f $nicModel,$nicMac)})"
    if (-not $NoNetwork) { Write-Host "  NIC PCI:     00:03.0 (fixed i440fx PCI slot)"; Write-Host "  NAT:         QEMU user network / DHCP+DNS through host connection" }
    Write-Host "  Host log:    $HostLog"
    Write-Host "  QEMU stderr: $QemuStderr"
    Write-Host "  Serial log:  $SerialLog"
    Write-Host ''
    Write-Stage 'Launching QEMU. This console will remain open while the VM is running.'

    # Run natively so PowerShell preserves each QEMU argument exactly, including
    # paths containing spaces. Native stderr is diagnostic; only the QEMU exit
    # code determines whether the process failed.
    $exitCode = Invoke-NativeLogged -Exe $Qemu -Arguments $args -Stdout $QemuStdout -Stderr $QemuStderr

    Write-Host "QEMU exited with code $exitCode"
    if ((Test-Path -LiteralPath $QemuStderr) -and ((Get-Item -LiteralPath $QemuStderr).Length -gt 0)) {
        Write-Host "QEMU wrote diagnostics/warnings to: $QemuStderr" -ForegroundColor Yellow
    }
    if ($exitCode -ne 0) {
        Show-FileTail $QemuStderr 80
        throw "QEMU exited with code $exitCode. The exact error is in $QemuStderr"
    }

    Copy-Item -LiteralPath $HostLog -Destination $LatestHost -Force -ErrorAction SilentlyContinue
    if (Test-Path -LiteralPath $QemuStderr) { Copy-Item -LiteralPath $QemuStderr -Destination $LatestStderr -Force -ErrorAction SilentlyContinue }
    Remove-Item -LiteralPath $LastErrorFile -Force -ErrorAction SilentlyContinue
    Write-Host 'NEXUS VM ended normally.' -ForegroundColor Green
    $exitCode = 0
}
catch {
    $exitCode = 1
    $errText = @"
NEXUS VM STARTUP FAILURE
Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
BootPath: $BootPath
Profile: $Profile
Message: $($_.Exception.Message)
Category: $($_.CategoryInfo)
Position: $($_.InvocationInfo.PositionMessage)
Script stack:
$($_.ScriptStackTrace)

QEMU stderr file: $QemuStderr
Host transcript: $HostLog
"@
    Set-Content -LiteralPath $LastErrorFile -Value $errText -Encoding UTF8
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Red
    Write-Host 'NEXUS VM FAILED - THE WINDOW WILL NOT AUTO-CLOSE' -ForegroundColor Red
    Write-Host '============================================================' -ForegroundColor Red
    Write-Host $errText -ForegroundColor Red
    Show-FileTail $QemuStderr 80
    try { Copy-Item -LiteralPath $HostLog -Destination $LatestHost -Force -ErrorAction SilentlyContinue } catch {}
    try { if (Test-Path -LiteralPath $QemuStderr) { Copy-Item -LiteralPath $QemuStderr -Destination $LatestStderr -Force -ErrorAction SilentlyContinue } } catch {}
}
finally {
    if ($transcriptStarted) {
        try { Stop-Transcript | Out-Null } catch {}
    }
}

if ($exitCode -ne 0 -and $PauseOnError) {
    Write-Host ''
    Write-Host 'Press ENTER only after you have read/copied the error above.' -ForegroundColor Yellow
    [void](Read-Host)
}
exit $exitCode
