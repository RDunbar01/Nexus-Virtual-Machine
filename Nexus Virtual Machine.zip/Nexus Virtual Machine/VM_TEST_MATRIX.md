# NEXUS VM Test Matrix

## Strong VM tests

- UEFI boot path
- Kernel startup and exception handling
- Desktop/shell lifecycle
- File Explorer behavior
- NEXUS Office HTML runtime
- NEXUS Foundry HTML runtime
- Governance/dashboard HTML applications
- Browser UI and rendering logic
- Generic USB mass-storage stack
- i440fx/PCI-facing VM device behavior (network qualification profile; storage remains independently gated)
- QEMU e1000 / Intel 82540EM (8086:100E) NEXUS-compatible virtual networking
- File read/write/delete/restore logic
- Crash recovery and regression testing
- Serial diagnostics once NEXUS emits COM output

## Partial VM tests

- Generic multi-monitor logic with additional virtual displays
- Generic sound
- Webcam/microphone logic if explicit QEMU forwarding is added
- Performance architecture

## Bare-metal tests still required

- AMD Radeon RX 7900 XT driver and acceleration
- MediaTek MT7922 Wi-Fi/firmware
- Real motherboard SATA/NVMe quirks
- Physical USB-to-HDMI adapters
- Motherboard iGPU + discrete GPU dual-monitor routing
- Real printers, webcams and microphones
- Secure Boot key enrollment against actual motherboard firmware


## v4 CPU baseline
The default VM CPU is `qemu64,hypervisor=on,svm=off,vmx=off`. This deliberately disables nested virtualization because it is irrelevant to normal NEXUS OS testing and can conflict with WHPX host feature filtering. Use **Force TCG** only as a diagnostic fallback when WHPX itself is unstable.

## W1.1R3 expected VM result

- Boot mode remains Normal in QEMU even if the M48 persistent attempt journal cannot be committed, provided the verified hypervisor-only fallback gate is met.
- Network DMA policy remains enabled.
- QEMU presents `e1000` / `8086:100E`.
- NEXUS attaches the virtual Ethernet provider automatically on a normal VM boot without enabling automatic VM storage writes.
- The Network settings page distinguishes physical Wi-Fi from the QEMU virtual Ethernet provider.
- Browser networking uses QEMU NAT through the host connection after guest DHCP; the guest is not expected to display the host's Wi-Fi SSID list.


## W1.1R3 acceptance delta

- [ ] Native desktop remains active after firmware handoff.
- [ ] VM Internet provider discovers `8086:100E` even if UEFI PCI-I/O omitted it.
- [ ] M48 physical Wi-Fi/storage Safe Mode flags do not suppress the e1000 virtual driver.
- [ ] e1000 BAR0/MMIO is admitted and the driver starts.
- [ ] DHCP obtains an address via QEMU user-mode NAT.
- [ ] DNS and NEXUS Browser reach an Internet host.
- [ ] No claim is made that the VM can scan host Wi-Fi SSIDs without WLAN passthrough.
