[CmdletBinding()]
param(
    [string]$BootPath,
    [ValidateSet('Compat','Legacy','Modern')]
    [string]$Profile = 'Compat'
)
$ErrorActionPreference = 'Continue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogDir = Join-Path $Root 'logs'
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log = Join-Path $LogDir ("diagnostics-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
$LastDiag = Join-Path $LogDir 'latest-diagnostics.log'

function Out-Diag([string]$Text,[ConsoleColor]$Color=[ConsoleColor]::Gray) {
    Write-Host $Text -ForegroundColor $Color
    Add-Content -LiteralPath $Log -Value $Text -Encoding UTF8
}
function Find-Qemu([string]$Name) {
    $cmd = Get-Command $Name -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $roots = @(
        (Join-Path $env:ProgramFiles 'qemu'),
        $(if (${env:ProgramFiles(x86)}) { Join-Path ${env:ProgramFiles(x86)} 'qemu' }),
        (Join-Path $env:LOCALAPPDATA 'Programs\qemu'),
        (Join-Path $env:LOCALAPPDATA 'qemu')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) }
    foreach ($r in $roots) {
        $p = Join-Path $r $Name
        if (Test-Path -LiteralPath $p -PathType Leaf) { return $p }
    }
    $regRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($rr in $regRoots) {
        $apps = Get-ItemProperty $rr -ErrorAction SilentlyContinue | Where-Object {
            $_.DisplayName -match 'QEMU' -and $_.InstallLocation
        }
        foreach ($app in $apps) {
            $p = Join-Path $app.InstallLocation $Name
            if (Test-Path -LiteralPath $p -PathType Leaf) { return $p }
        }
    }
    return $null
}

Out-Diag '============================================================' Cyan
Out-Diag 'NEXUS VM LAB v9 DIAGNOSTICS' Cyan
Out-Diag ("Time: {0}" -f (Get-Date))
Out-Diag ("Windows: {0}" -f [Environment]::OSVersion.VersionString)
Out-Diag ("PowerShell: {0}" -f $PSVersionTable.PSVersion)
Out-Diag ("64-bit process: {0}" -f [Environment]::Is64BitProcess)
Out-Diag ("Profile requested: {0}" -f $Profile)
Out-Diag ''

$qemu = Find-Qemu 'qemu-system-x86_64.exe'
$qemuImg = Find-Qemu 'qemu-img.exe'
if (-not $qemu) {
    Out-Diag 'FAIL: qemu-system-x86_64.exe was not found.' Red
    Out-Diag 'Run Setup / Check QEMU first.' Yellow
} else {
    Out-Diag ("PASS: QEMU = {0}" -f $qemu) Green
    $version = (& $qemu --version 2>&1 | Select-Object -First 1 | Out-String).Trim()
    Out-Diag ("Version: {0}" -f $version)
    Out-Diag 'Guest CPU policy: qemu64,hypervisor=on,svm=off,vmx=off (VM detection forced; nested virtualization disabled)' Green
    $accel = (& $qemu -accel help 2>&1 | Out-String)
    Out-Diag 'Accelerators:'
    Out-Diag $accel
    $machines = (& $qemu -machine help 2>&1 | Out-String)
    $needMachine = 'pc'
    if ($machines -match ('(?m)^' + [regex]::Escape($needMachine) + '\s')) { Out-Diag ("PASS: machine {0}" -f $needMachine) Green }
    else { Out-Diag ("FAIL: machine {0} not available" -f $needMachine) Red }

    $devices = (& $qemu -device help 2>&1 | Out-String)
    $need = @('usb-kbd','usb-tablet','usb-storage')
    if ($Profile -ne 'Legacy') { $need += @('qemu-xhci') }
    $need += @('e1000') # NEXUS W1.1R3 guest network provider
    foreach ($d in $need) {
        if ($devices -match [regex]::Escape($d)) { Out-Diag ("PASS: device {0}" -f $d) Green }
        else { Out-Diag ("FAIL: device {0}" -f $d) Red }
    }

    $qemuDir = Split-Path -Parent $qemu
    Out-Diag ("Scanning firmware beneath: {0}" -f $qemuDir)
    $fw = @(Get-ChildItem -LiteralPath $qemuDir -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^(edk2|OVMF).*(code|vars).*\.fd$' })
    if ($fw.Count -eq 0) { Out-Diag 'FAIL: No matching EDK2/OVMF .fd firmware files found.' Red }
    else {
        Out-Diag 'Firmware candidates:' Green
        foreach ($f in $fw) { Out-Diag ("  {0}" -f $f.FullName) }
    }
}

if (-not $qemuImg) { Out-Diag 'FAIL: qemu-img.exe was not found.' Red }
else { Out-Diag ("PASS: qemu-img = {0}" -f $qemuImg) Green }

try {
    $feature = Get-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform -ErrorAction Stop
    Out-Diag ("Windows Hypervisor Platform: {0}" -f $feature.State) $(if ($feature.State -eq 'Enabled') {[ConsoleColor]::Green} else {[ConsoleColor]::Yellow})
} catch {
    Out-Diag ("NOTE: Could not query HypervisorPlatform state: {0}" -f $_.Exception.Message) Yellow
}

if ($BootPath) {
    try {
        $full = [IO.Path]::GetFullPath($BootPath)
        if (Test-Path -LiteralPath $full -PathType Leaf) {
            $item = Get-Item -LiteralPath $full
            Out-Diag ("PASS: Boot image exists: {0}" -f $full) Green
            Out-Diag ("Image size: {0:N2} MB" -f ($item.Length/1MB))
            Out-Diag ("Extension: {0}" -f $item.Extension)
            if ($qemuImg -and $item.Extension -ne '.iso') {
                Out-Diag 'qemu-img info:'
                $info = (& $qemuImg info -f raw $full 2>&1 | Out-String)
                Out-Diag $info
            }
        } else { Out-Diag ("FAIL: Boot image does not exist: {0}" -f $full) Red }
    } catch { Out-Diag ("FAIL checking boot image: {0}" -f $_.Exception.Message) Red }
} else {
    Out-Diag 'No boot image was supplied to diagnostics; QEMU-only checks completed.' Yellow
}

Copy-Item -LiteralPath $Log -Destination $LastDiag -Force -ErrorAction SilentlyContinue
Out-Diag ''
Out-Diag ("Diagnostics written to: {0}" -f $Log) Cyan
Out-Diag 'This window is intentionally left open by the launcher.' Yellow
