@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0NEXUS-VM-Lab.ps1"
if errorlevel 1 pause
