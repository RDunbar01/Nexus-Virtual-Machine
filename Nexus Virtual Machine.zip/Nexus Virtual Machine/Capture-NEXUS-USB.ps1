[CmdletBinding()]
param(
    [int]$DiskNumber = -1,
    [string]$OutputPath
)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ImageDir = Join-Path $Root 'images'
$LogDir = Join-Path $Root 'logs'
New-Item -ItemType Directory -Force -Path $ImageDir,$LogDir | Out-Null
$Log = Join-Path $LogDir ("usb-capture-{0}.log" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
Start-Transcript -Path $Log -Force | Out-Null
try {
    function Find-QemuImg {
        $cmd = Get-Command 'qemu-img.exe' -ErrorAction SilentlyContinue
        if ($cmd) { return $cmd.Source }
        $candidates = @(
            (Join-Path $env:ProgramFiles 'qemu\qemu-img.exe'),
            $(if (${env:ProgramFiles(x86)}) { Join-Path ${env:ProgramFiles(x86)} 'qemu\qemu-img.exe' }),
            (Join-Path $env:LOCALAPPDATA 'Programs\qemu\qemu-img.exe')
        ) | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) }
        if ($candidates.Count -gt 0) { return $candidates[0] }
        throw 'qemu-img.exe was not found. Run Setup / Check QEMU first.'
    }

    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'USB capture needs Administrator privileges because Windows restricts raw physical-disk reads.'
    }

    $usb = @(Get-Disk | Where-Object { $_.BusType -eq 'USB' -and $_.OperationalStatus -ne 'Offline' })
    if ($usb.Count -eq 0) { throw 'No online USB disks were detected.' }

    Write-Host 'Detected USB disks:' -ForegroundColor Cyan
    $usb | Select-Object Number,FriendlyName,@{N='SizeGB';E={[math]::Round($_.Size/1GB,2)}},PartitionStyle,OperationalStatus | Format-Table -AutoSize

    if ($DiskNumber -lt 0) { $DiskNumber = [int](Read-Host 'Enter the USB disk NUMBER containing NEXUS') }
    $disk = $usb | Where-Object Number -eq $DiskNumber
    if (-not $disk) { throw "Disk $DiskNumber is not one of the detected USB disks. Refusing to access it." }

    if (-not $OutputPath) {
        $OutputPath = Join-Path $ImageDir ("NEXUS_USB_Disk{0}_{1}.img" -f $DiskNumber,(Get-Date -Format 'yyyyMMdd-HHmmss'))
    }
    $OutputPath = [IO.Path]::GetFullPath($OutputPath)
    if (Test-Path -LiteralPath $OutputPath) { throw "Output already exists: $OutputPath" }

    $driveRoot = [IO.Path]::GetPathRoot($OutputPath)
    if ($driveRoot) {
        $di = New-Object IO.DriveInfo($driveRoot)
        if ($di.AvailableFreeSpace -lt $disk.Size) {
            throw ("Not enough free space. USB size is {0:N2} GB; destination has {1:N2} GB free." -f ($disk.Size/1GB),($di.AvailableFreeSpace/1GB))
        }
    }

    $qemuImg = Find-QemuImg
    $source = "\\.\PhysicalDrive$DiskNumber"
    Write-Host "Capturing READ-ONLY source $source" -ForegroundColor Green
    Write-Host "Output: $OutputPath"
    Write-Host 'The physical USB is never attached read/write to the VM by this workflow.' -ForegroundColor Yellow

    & $qemuImg convert -p -f raw -O raw $source $OutputPath
    if ($LASTEXITCODE -ne 0) { throw "qemu-img capture failed with exit code $LASTEXITCODE" }

    Write-Host 'USB image capture complete.' -ForegroundColor Green
    Write-Host "Image: $OutputPath"
    Write-Host "Capture log: $Log"
}
catch {
    $text = $_ | Format-List * -Force | Out-String
    Set-Content -LiteralPath (Join-Path $LogDir 'LAST_ERROR.txt') -Value $text -Encoding UTF8
    Write-Host $text -ForegroundColor Red
    throw
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
}
