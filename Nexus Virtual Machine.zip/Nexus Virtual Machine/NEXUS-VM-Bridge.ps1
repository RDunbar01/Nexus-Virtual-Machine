[CmdletBinding()]
param(
    [int]$Port = 8765,
    [string]$SessionToken = ''
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogDir = Join-Path $Root 'logs'
$StateDir = Join-Path $Root 'state'
$ImageDir = Join-Path $Root 'images'
New-Item -ItemType Directory -Force -Path $LogDir,$StateDir,$ImageDir | Out-Null
$BridgeLog = Join-Path $LogDir 'web-bridge.log'
$LastErrorFile = Join-Path $LogDir 'LAST_ERROR.txt'
$HtmlPath = Join-Path $Root 'NEXUS-VM-Lab.html'
$StartScript = Join-Path $Root 'Start-NEXUS-VM.ps1'
$SetupScript = Join-Path $Root 'Setup-NEXUS-VM.ps1'
$DiagScript = Join-Path $Root 'Preflight-NEXUS-VM.ps1'
$CaptureScript = Join-Path $Root 'Capture-NEXUS-USB.ps1'
$ResetScript = Join-Path $Root 'Reset-NEXUS-VM.ps1'
$SelectScript = Join-Path $Root 'Select-NEXUS-Image.ps1'
$BridgeStateFile = Join-Path $StateDir 'web-bridge.json'
$VmPidFile = Join-Path $StateDir 'last-vm-wrapper.pid'

function Write-BridgeLog([string]$Message) {
    try {
        $line = ('{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'),$Message)
        Add-Content -LiteralPath $BridgeLog -Value $line -Encoding UTF8 -ErrorAction Stop
    } catch { }
}

function Record-BridgeError([System.Management.Automation.ErrorRecord]$Err,[string]$Context) {
    $text = @"
NEXUS VM Lab web-bridge failure
Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Context: $Context
Message: $($Err.Exception.Message)
Category: $($Err.CategoryInfo)
Position: $($Err.InvocationInfo.PositionMessage)
Script stack:
$($Err.ScriptStackTrace)
"@
    Set-Content -LiteralPath $LastErrorFile -Value $text -Encoding UTF8
    Write-BridgeLog ("ERROR [{0}] {1}" -f $Context,$Err.Exception.Message)
    return $text
}

function Find-QemuGui {
    $cmd = Get-Command 'qemu-system-x86_64.exe' -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $paths = @(
        "$env:ProgramFiles\qemu\qemu-system-x86_64.exe",
        $(if (${env:ProgramFiles(x86)}) { "${env:ProgramFiles(x86)}\qemu\qemu-system-x86_64.exe" }),
        "$env:LOCALAPPDATA\Programs\qemu\qemu-system-x86_64.exe",
        "$env:LOCALAPPDATA\qemu\qemu-system-x86_64.exe"
    ) | Where-Object { $_ }
    foreach ($p in $paths) { if (Test-Path -LiteralPath $p -PathType Leaf) { return $p } }
    $regRoots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($rr in $regRoots) {
        $apps = Get-ItemProperty $rr -ErrorAction SilentlyContinue | Where-Object {
            $_.DisplayName -match 'QEMU' -and $_.InstallLocation
        }
        foreach ($app in $apps) {
            $p = Join-Path $app.InstallLocation 'qemu-system-x86_64.exe'
            if (Test-Path -LiteralPath $p -PathType Leaf) { return $p }
        }
    }
    return $null
}

function Get-WhpxState {
    try {
        $feature = Get-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform -ErrorAction Stop
        return [string]$feature.State
    } catch { return 'Unknown' }
}

function Get-VmStatus {
    if (-not (Test-Path -LiteralPath $VmPidFile -PathType Leaf)) { return @{ running=$false; pid=$null } }
    try {
        $pidValue = [int](Get-Content -LiteralPath $VmPidFile -Raw).Trim()
        $p = Get-Process -Id $pidValue -ErrorAction SilentlyContinue
        if ($p) { return @{ running=$true; pid=$pidValue } }
    } catch {}
    return @{ running=$false; pid=$null }
}

function Json([object]$Value) {
    return ($Value | ConvertTo-Json -Depth 8 -Compress)
}

function Send-Response($Stream,[int]$Status,[string]$ContentType,[string]$Content) {
    $statusText = switch ($Status) {
        200 {'OK'} 201 {'Created'} 202 {'Accepted'} 204 {'No Content'} 400 {'Bad Request'}
        401 {'Unauthorized'} 404 {'Not Found'} 409 {'Conflict'} 500 {'Internal Server Error'}
        default {'OK'}
    }
    $bytes = [Text.Encoding]::UTF8.GetBytes($Content)
    $header = "HTTP/1.1 $Status $statusText`r`nContent-Type: $ContentType`r`nContent-Length: $($bytes.Length)`r`nCache-Control: no-store, no-cache, must-revalidate`r`nPragma: no-cache`r`nX-Content-Type-Options: nosniff`r`nConnection: close`r`n`r`n"
    $headBytes = [Text.Encoding]::ASCII.GetBytes($header)
    $Stream.Write($headBytes,0,$headBytes.Length)
    if ($bytes.Length -gt 0) { $Stream.Write($bytes,0,$bytes.Length) }
    $Stream.Flush()
}

function Send-Json($Stream,[int]$Status,[object]$Object) {
    Send-Response $Stream $Status 'application/json; charset=utf-8' (Json $Object)
}

function Parse-Query([string]$Query) {
    $result = @{}
    if ([string]::IsNullOrWhiteSpace($Query)) { return $result }
    foreach ($part in $Query.TrimStart('?').Split('&')) {
        if (-not $part) { continue }
        $kv = $part.Split('=',2)
        $key = [Uri]::UnescapeDataString($kv[0].Replace('+',' '))
        $value = if ($kv.Length -gt 1) { [Uri]::UnescapeDataString($kv[1].Replace('+',' ')) } else { '' }
        $result[$key] = $value
    }
    return $result
}

function Get-RequestBody($Reader,[hashtable]$Headers) {
    $length = 0
    if ($Headers.ContainsKey('content-length')) { [void][int]::TryParse($Headers['content-length'],[ref]$length) }
    if ($length -le 0) { return '' }
    $buffer = New-Object char[] $length
    $offset = 0
    while ($offset -lt $length) {
        $n = $Reader.Read($buffer,$offset,$length-$offset)
        if ($n -le 0) { break }
        $offset += $n
    }
    if ($offset -le 0) { return '' }
    return (-join $buffer[0..($offset-1)])
}

function Get-JsonBody([string]$Body) {
    if ([string]::IsNullOrWhiteSpace($Body)) { return [pscustomobject]@{} }
    return ($Body | ConvertFrom-Json)
}

function Get-FileTailText([string]$Path,[int]$Lines=180) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return '' }
    return ((Get-Content -LiteralPath $Path -Tail $Lines -ErrorAction SilentlyContinue) -join "`n")
}

function Resolve-LogKind([string]$Kind) {
    switch ($Kind) {
        'host' { return (Join-Path $LogDir 'latest-host.log') }
        'stderr' { return (Join-Path $LogDir 'latest-qemu-stderr.log') }
        'diagnostics' { return (Join-Path $LogDir 'latest-diagnostics.log') }
        'error' { return $LastErrorFile }
        'bridge' { return $BridgeLog }
        default { return (Join-Path $LogDir 'latest-host.log') }
    }
}

function Start-HiddenPowerShell([string]$Script,[string[]]$Arguments) {
    $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $Script)) + $Arguments
    return Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -WorkingDirectory $Root -WindowStyle Hidden -PassThru
}

function Require-Image([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { throw 'Select a NEXUS ISO or IMG first.' }
    $full = [IO.Path]::GetFullPath($Path)
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) { throw "Boot image not found: $full" }
    return $full
}

$listener = $null
$running = $true
try {
    if (-not (Test-Path -LiteralPath $HtmlPath -PathType Leaf)) { throw "HTML interface missing: $HtmlPath" }
    Write-BridgeLog 'Starting NEXUS VM HTML bridge.'
    if ([string]::IsNullOrWhiteSpace($SessionToken)) { $SessionToken = [Guid]::NewGuid().ToString('N') }
    $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$Port)
    $listener.Start()
    $actualPort = ([Net.IPEndPoint]$listener.LocalEndpoint).Port
    $state = [ordered]@{ pid=$PID; port=$actualPort; token=$SessionToken; started=(Get-Date).ToString('o') }
    Set-Content -LiteralPath $BridgeStateFile -Value (Json $state) -Encoding UTF8
    $url = "http://127.0.0.1:$actualPort/?token=$SessionToken"
    Write-BridgeLog "Listening at http://127.0.0.1:$actualPort/"

    while ($running) {
        $client = $listener.AcceptTcpClient()
        try {
            $stream = $client.GetStream()
            $reader = New-Object IO.StreamReader($stream,[Text.Encoding]::UTF8,$false,4096,$true)
            $requestLine = $reader.ReadLine()
            if ([string]::IsNullOrWhiteSpace($requestLine)) { continue }
            $parts = $requestLine.Split(' ')
            if ($parts.Length -lt 2) { Send-Json $stream 400 @{ok=$false;error='Malformed request.'}; continue }
            $method = $parts[0].ToUpperInvariant()
            $target = $parts[1]
            $headers = @{}
            while ($true) {
                $line = $reader.ReadLine()
                if ($null -eq $line -or $line -eq '') { break }
                $idx = $line.IndexOf(':')
                if ($idx -gt 0) { $headers[$line.Substring(0,$idx).Trim().ToLowerInvariant()] = $line.Substring($idx+1).Trim() }
            }
            $uri = [Uri]("http://127.0.0.1:$actualPort$target")
            $path = $uri.AbsolutePath
            $query = Parse-Query $uri.Query
            $body = Get-RequestBody $reader $headers

            if ($path -eq '/' -or $path -eq '/index.html' -or $path -eq '/NEXUS-VM-Lab.html') {
                $html = Get-Content -LiteralPath $HtmlPath -Raw -Encoding UTF8
                Send-Response $stream 200 'text/html; charset=utf-8' $html
                continue
            }

            if (-not $path.StartsWith('/api/')) { Send-Json $stream 404 @{ok=$false;error='Not found.'}; continue }
            $providedToken = if ($headers.ContainsKey('x-nexus-token')) { $headers['x-nexus-token'] } else { '' }
            if ($providedToken -ne $SessionToken) { Send-Json $stream 401 @{ok=$false;error='Invalid NEXUS bridge token.'}; continue }

            try {
                switch ($path) {
                    '/api/ping' {
                        Send-Json $stream 200 @{ok=$true;bridge='NEXUS VM Studio';version='6';pid=$PID;port=$actualPort}
                    }
                    '/api/status' {
                        $qemu = Find-QemuGui
                        $qemuVersion = $null
                        if ($qemu) { $qemuVersion = (& $qemu --version 2>&1 | Select-Object -First 1 | Out-String).Trim() }
                        $vm = Get-VmStatus
                        Send-Json $stream 200 @{
                            ok=$true; qemuReady=[bool]$qemu; qemuPath=$qemu; qemuVersion=$qemuVersion;
                            whpx=Get-WhpxState; vmRunning=$vm.running; vmPid=$vm.pid;
                            root=$Root; logs=$LogDir; bridgePid=$PID
                        }
                    }
                    '/api/browse' {
                        if ($method -ne 'POST') { throw 'POST required.' }
                        if (-not (Test-Path -LiteralPath $SelectScript -PathType Leaf)) { throw "Image selector helper missing: $SelectScript" }
                        $resultFile = Join-Path $StateDir ("browse-{0}.json" -f ([Guid]::NewGuid().ToString('N')))
                        try {
                            $selectArgs = @('-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $SelectScript),'-OutputFile',('"{0}"' -f $resultFile))
                            $proc = Start-Process -FilePath 'powershell.exe' -ArgumentList $selectArgs -WorkingDirectory $Root -WindowStyle Hidden -PassThru
                            if (-not $proc.WaitForExit(120000)) {
                                try { $proc.Kill() } catch {}
                                throw 'The Windows image selector did not respond within 120 seconds.'
                            }
                            if (-not (Test-Path -LiteralPath $resultFile -PathType Leaf)) { throw 'The Windows image selector returned no result.' }
                            $selection = Get-Content -LiteralPath $resultFile -Raw -Encoding UTF8 | ConvertFrom-Json
                            if ($selection.error) { throw [string]$selection.error }
                            if ([bool]$selection.selected) {
                                $full = Require-Image ([string]$selection.path)
                                $item = Get-Item -LiteralPath $full
                                Write-BridgeLog ("Image selected: {0}" -f $full)
                                Send-Json $stream 200 @{ok=$true;selected=$true;path=$full;name=$item.Name;bytes=$item.Length;mb=[math]::Round($item.Length/1MB,2);extension=$item.Extension}
                            } else { Send-Json $stream 200 @{ok=$true;selected=$false} }
                        } finally {
                            Remove-Item -LiteralPath $resultFile -Force -ErrorAction SilentlyContinue
                        }
                    }
                    '/api/image-info' {
                        $data = Get-JsonBody $body
                        $full = Require-Image ([string]$data.path)
                        $item = Get-Item -LiteralPath $full
                        Send-Json $stream 200 @{ok=$true;path=$full;name=$item.Name;bytes=$item.Length;mb=[math]::Round($item.Length/1MB,2);extension=$item.Extension}
                    }
                    '/api/start' {
                        if ($method -ne 'POST') { throw 'POST required.' }
                        $data = Get-JsonBody $body
                        $full = Require-Image ([string]$data.bootPath)
                        $qemu = Find-QemuGui
                        if (-not $qemu) { Send-Json $stream 409 @{ok=$false;error='QEMU is not installed. Use Setup / QEMU.'}; continue }
                        $profile = if (@('Compat','Legacy','Modern') -contains [string]$data.profile) { [string]$data.profile } else { 'Compat' }
                        $memory = [int]$data.memoryMB; if ($memory -lt 512 -or $memory -gt 65536) { $memory = 4096 }
                        $cpus = [int]$data.cpus; if ($cpus -lt 1 -or $cpus -gt 32) { $cpus = 4 }
                        $args = @('-BootPath',('"{0}"' -f $full),'-Profile',$profile,'-MemoryMB',[string]$memory,'-CPUs',[string]$cpus)
                        if ([bool]$data.resetOverlay) { $args += '-ResetOverlay' }
                        if ([bool]$data.forceTcg) { $args += '-NoWHPX' }
                        if (-not [bool]$data.network) { $args += '-NoNetwork' }
                        if ([bool]$data.ephemeral) { $args += '-Ephemeral' }
                        $proc = Start-HiddenPowerShell $StartScript $args
                        Set-Content -LiteralPath $VmPidFile -Value ([string]$proc.Id) -Encoding ASCII
                        Write-BridgeLog ("Started VM wrapper PID={0}; profile={1}; RAM={2}; CPUs={3}; TCG={4}; image={5}" -f $proc.Id,$profile,$memory,$cpus,[bool]$data.forceTcg,$full)
                        Send-Json $stream 202 @{ok=$true;pid=$proc.Id;message='NEXUS VM launch initiated.'}
                    }
                    '/api/stop' {
                        $vm = Get-VmStatus
                        if (-not $vm.running) { Send-Json $stream 200 @{ok=$true;stopped=$false;message='No tracked VM is running.'}; continue }
                        & taskkill.exe /PID ([string]$vm.pid) /T /F 2>&1 | Out-Null
                        Start-Sleep -Milliseconds 250
                        Write-BridgeLog ("Stopped tracked VM process tree PID={0}" -f $vm.pid)
                        Send-Json $stream 200 @{ok=$true;stopped=$true;message='Tracked NEXUS VM process tree stopped.'}
                    }
                    '/api/diagnostics' {
                        $data = Get-JsonBody $body
                        $args = @()
                        if ($data.bootPath) {
                            try { $full = Require-Image ([string]$data.bootPath); $args += @('-BootPath',('"{0}"' -f $full)) } catch {}
                        }
                        $profile = if (@('Compat','Legacy','Modern') -contains [string]$data.profile) { [string]$data.profile } else { 'Compat' }
                        $args += @('-Profile',$profile)
                        $proc = Start-HiddenPowerShell $DiagScript $args
                        Write-BridgeLog ("Started diagnostics PID={0}" -f $proc.Id)
                        Send-Json $stream 202 @{ok=$true;pid=$proc.Id;message='Diagnostics started.'}
                    }
                    '/api/setup' {
                        $data = Get-JsonBody $body
                        $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $SetupScript))
                        if ([bool]$data.enableWhpx) { $args += '-EnableWHPX' }
                        $proc = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $args -WorkingDirectory $Root -WindowStyle Normal -PassThru
                        Write-BridgeLog ("Started elevated QEMU setup PID={0}; EnableWHPX={1}" -f $proc.Id,[bool]$data.enableWhpx)
                        Send-Json $stream 202 @{ok=$true;pid=$proc.Id;message='QEMU setup/check opened with Administrator rights.'}
                    }
                    '/api/open-logs' {
                        Start-Process explorer.exe -ArgumentList ('"{0}"' -f $LogDir) | Out-Null
                        Send-Json $stream 200 @{ok=$true}
                    }
                    '/api/reset-overlays' {
                        $proc = Start-HiddenPowerShell $ResetScript @('-Confirm:$false')
                        $proc.WaitForExit()
                        Write-BridgeLog 'Reset COW overlay request completed.'
                        Send-Json $stream 200 @{ok=($proc.ExitCode -eq 0);exitCode=$proc.ExitCode;message='COW overlays reset.'}
                    }
                    '/api/usb-disks' {
                        try {
                            $usb = @(Get-Disk | Where-Object { $_.BusType -eq 'USB' -and $_.OperationalStatus -ne 'Offline' } | ForEach-Object {
                                [ordered]@{number=$_.Number;name=$_.FriendlyName;sizeGB=[math]::Round($_.Size/1GB,2);style=[string]$_.PartitionStyle;status=($_.OperationalStatus -join ', ')}
                            })
                            Send-Json $stream 200 @{ok=$true;disks=$usb}
                        } catch { Send-Json $stream 500 @{ok=$false;error=$_.Exception.Message} }
                    }
                    '/api/capture-usb' {
                        $data = Get-JsonBody $body
                        $disk = [int]$data.diskNumber
                        if ($disk -lt 0) { throw 'Select a USB disk number first.' }
                        $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $CaptureScript),'-DiskNumber',[string]$disk)
                        $proc = Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $args -WorkingDirectory $Root -WindowStyle Normal -PassThru
                        Write-BridgeLog ("Started elevated USB capture for Disk {0}; PID={1}" -f $disk,$proc.Id)
                        Send-Json $stream 202 @{ok=$true;pid=$proc.Id;message="Capture started for USB Disk $disk. Output will be stored under images\\."}
                    }
                    '/api/log' {
                        $kind = if ($query.ContainsKey('kind')) { [string]$query['kind'] } else { 'host' }
                        $logPath = Resolve-LogKind $kind
                        Send-Json $stream 200 @{ok=$true;kind=$kind;path=$logPath;text=(Get-FileTailText $logPath 220)}
                    }
                    '/api/shutdown' {
                        Send-Json $stream 200 @{ok=$true;message='NEXUS VM web bridge is shutting down.'}
                        $running = $false
                    }
                    default { Send-Json $stream 404 @{ok=$false;error='Unknown API endpoint.'} }
                }
            } catch {
                $msg = $_.Exception.Message
                Write-BridgeLog ("API ERROR {0}: {1}" -f $path,$msg)
                Send-Json $stream 500 @{ok=$false;error=$msg}
            }
        }
        catch {
            Write-BridgeLog ("Request failure: {0}" -f $_.Exception.Message)
        }
        finally {
            try { $client.Close() } catch {}
        }
    }
}
catch {
    $detail = Record-BridgeError $_ 'Bridge initialization/runtime'
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        [System.Windows.Forms.MessageBox]::Show($detail,'NEXUS VM Lab web bridge error','OK','Error') | Out-Null
    } catch {}
}
finally {
    try { if ($listener) { $listener.Stop() } } catch {}
    try { Remove-Item -LiteralPath $BridgeStateFile -Force -ErrorAction SilentlyContinue } catch {}
    Write-BridgeLog 'NEXUS VM HTML bridge stopped.'
}
