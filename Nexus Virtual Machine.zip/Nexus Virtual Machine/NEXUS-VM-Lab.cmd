@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist "%~dp0logs" mkdir "%~dp0logs" >nul 2>&1
if not exist "%~dp0state" mkdir "%~dp0state" >nul 2>&1

title NEXUS VM Studio v9 Launcher
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0NEXUS-VM-Launcher.ps1"
if errorlevel 1 pause
exit /b %errorlevel%
