# v6 Bridge Fix Notes

## Failure seen in v5

The HTML control surface could render while its loopback PowerShell backend was not reachable. Because SELECT IMAGE depended on `/api/browse`, the button appeared inert when the bridge was offline.

## v6 changes

- Added a launcher-level bridge health gate.
- Browser opens only after `/api/ping` succeeds.
- Stable per-lab bridge token survives bridge relaunches.
- Port collision fallback covers 8765–8774.
- Bridge stdout and stderr are persisted from process start.
- Directly opening the HTML file is detected and explicitly marked offline.
- Recheck Bridge button added to the UI.
- OpenFileDialog moved to a separate STA helper process.
- File selector uses a top-most Windows Forms owner so the dialog does not hide behind the browser.
- The boot path field remains manually editable.
- Repeated status polling no longer spams failure toasts.
- Bridge logging itself is non-fatal if a log write fails.

## Boundary

The user interface is HTML, but QEMU launch, native full-path selection, USB enumeration/capture, and host-log access still require a local native bridge. This is a host-security boundary imposed by ordinary browsers, not a NEXUS guest limitation.
