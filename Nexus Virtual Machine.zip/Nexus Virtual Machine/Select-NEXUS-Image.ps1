[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][string]$OutputFile
)

$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()

    $owner = New-Object System.Windows.Forms.Form
    $owner.Text = 'NEXUS VM Studio'
    $owner.StartPosition = 'CenterScreen'
    $owner.Size = New-Object System.Drawing.Size(1,1)
    $owner.ShowInTaskbar = $false
    $owner.TopMost = $true
    $owner.Opacity = 0
    $owner.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
    $owner.Show()
    $owner.Activate()

    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Filter = 'NEXUS boot images (*.iso;*.img;*.raw;*.bin)|*.iso;*.img;*.raw;*.bin|All files (*.*)|*.*'
    $dialog.Title = 'Select NEXUS OS boot image'
    $dialog.CheckFileExists = $true
    $dialog.CheckPathExists = $true
    $dialog.Multiselect = $false
    $dialog.RestoreDirectory = $true

    $result = $dialog.ShowDialog($owner)
    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        $payload = [ordered]@{ selected=$true; path=$dialog.FileName }
    } else {
        $payload = [ordered]@{ selected=$false }
    }
    $owner.Close()
    $payload | ConvertTo-Json -Compress | Set-Content -LiteralPath $OutputFile -Encoding UTF8
    exit 0
}
catch {
    try {
        [ordered]@{ selected=$false; error=$_.Exception.Message } | ConvertTo-Json -Compress | Set-Content -LiteralPath $OutputFile -Encoding UTF8
    } catch { }
    exit 1
}
